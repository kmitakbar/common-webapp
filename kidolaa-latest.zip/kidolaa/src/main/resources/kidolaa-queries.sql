sample_create=insert into sample(name,phone,email) values(?,?,?)
sample_update=update sample set name=?, phone=?,email=? where sample_id=?
sample_delete=delete from sample where sample_id=?
sample_get=select * from sample where sample_id=?
sample_get_list=select * from sample

--user related queries
create_user=insert into users(firstname,lastname,email,loginname,password,created_dtm)values(?,?,?,?,?,now())
get_user_by_id=select * from users where userId=?
get_user_uname_pwd=select * from users where loginname=? and password=?

