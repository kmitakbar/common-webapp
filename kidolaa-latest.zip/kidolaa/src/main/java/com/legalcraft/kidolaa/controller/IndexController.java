package com.legalcraft.kidolaa.controller;

import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.legalcraft.kidolaa.model.KidolaaThreadLocal;
import com.legalcraft.kidolaa.model.UserContext;
import com.legalcraft.kidolaa.model.WebResponse;
import com.legalcraft.kidolaa.service.UserService;

@RestController
@RequestMapping("/api/v1")
public class IndexController {

	public Logger log = LoggerFactory.getLogger(IndexController.class);

	ObjectMapper mapper = new ObjectMapper();

	@Autowired
	ApplicationContext ApplicationContext;
	
	@Autowired
	UserService user;

	@RequestMapping(value = "/{service}/{operation}", method = RequestMethod.POST)
	public @ResponseBody WebResponse commonPost(@PathVariable String service, @PathVariable String operation,
			@RequestBody String formData) throws Exception {
		log.debug("service::" + service + ";;;;;operation::::" + operation);
		Map<String, Object> map = mapper.readValue(formData, Map.class);
		Object obj = ApplicationContext.getBean(service);
		Object resData=null;
	    System.out.println("context after login:::"+KidolaaThreadLocal.getUserContext());
			resData = ApplicationContext.getBean(service).getClass().getDeclaredMethod(operation, Map.class)
					.invoke(obj, map);

		WebResponse webResponse = new WebResponse();
		webResponse.setResponse(resData);

		return webResponse;

	}

	@RequestMapping(value = "/{service}/{operation}/{id}", method = RequestMethod.GET)
	public @ResponseBody WebResponse commonGetById(@PathVariable String service, @PathVariable String operation,
			@PathVariable String id) throws Exception {
		log.debug("service::" + service + ";;;;;operation::::" + operation);
		Long entityId = null;
		Object resData = null;
		if (id != null && id != "") {
			entityId = Long.parseLong(id);
			try {
				Object obj = ApplicationContext.getBean(service);
				resData = ApplicationContext.getBean(service).getClass().getDeclaredMethod(operation, Long.class)
						.invoke(obj, entityId);
			} catch (Exception e) {
				log.error(e.getMessage());
			}

		}
		WebResponse webResponse = new WebResponse();
		webResponse.setResponse(resData);

		return webResponse;

	}

	@RequestMapping(value = "/{service}/{operation}", method = RequestMethod.GET)
	public @ResponseBody WebResponse commonGetList(@PathVariable String service, @PathVariable String operation)
			throws Exception {
		log.debug("service::" + service + ";;;;;operation::::" + operation);
		Long entityId = null;
		Object resData = null;
		try {
			Object obj = ApplicationContext.getBean(service);
			resData = ApplicationContext.getBean(service).getClass().getDeclaredMethod(operation, null).invoke(obj,
					null);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		WebResponse webResponse = new WebResponse();
		webResponse.setResponse(resData);

		return webResponse;

	}
	
	@RequestMapping("/login")
	public @ResponseBody WebResponse login(
			@RequestBody String formData) throws Exception {
		
		Map<String, Object> map = mapper.readValue(formData, Map.class);
		Object resData=null;
		
		 UserContext context=user.login(map);
		 resData = context;
		 if(context!=null){
			 KidolaaThreadLocal.setUserContext(context);
			 //KidolaaThreadLocal.localUser.set(context);
			 System.out.println("context:::"+KidolaaThreadLocal.localUser.get());
		}
		WebResponse webResponse = new WebResponse();
		webResponse.setResponse(resData);

		return webResponse;

	}
}
