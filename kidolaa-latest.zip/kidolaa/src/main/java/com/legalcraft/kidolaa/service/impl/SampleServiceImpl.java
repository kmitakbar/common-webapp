	package com.legalcraft.kidolaa.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.legalcraft.kidolaa.service.SampleService;
@Transactional
@Service("sampleService")
public class SampleServiceImpl extends BaseServiceImpl implements SampleService {

		
	public Logger log = LoggerFactory.getLogger(SampleServiceImpl.class);
	
	
	@Override
	public Map<String, Object> save(Map<String, Object> sampleMap) throws Exception {
		Map<String, Object> errorMsg=validateSave(sampleMap);
		System.out.println(errorMsg.size());
		if(errorMsg.isEmpty()){
		System.out.println("inside service impl..."+sampleMap);
		Object []params={sampleMap.get("name"),sampleMap.get("phone"),sampleMap.get("email")};
		Long sampleId=baseDao.save(propsReaderUtil.getValue("sample_create"), params);
		System.out.println("sampleId......."+sampleId);
		sampleMap.put("sampleId", sampleId);
		return sampleMap;
		}else{
			return errorMsg;
		}
	}

	@Override
	public Map<String, Object> update(Map<String, Object> sampleMap) throws Exception {
		System.out.println("inside ipdate service impl..."+sampleMap);
		Object []params={sampleMap.get("name"),sampleMap.get("phone"),sampleMap.get("emailId"),sampleMap.get("sampleId")};
		baseDao.update(propsReaderUtil.getValue("sample_update"), params);
		return sampleMap;
	}

	@Override
	public Map<String, Object> delete(Map<String, Object> sampleMap) throws Exception {
		System.out.println("inside ipdate service impl..."+sampleMap);
		Object []params={sampleMap.get("sampleId")};
		baseDao.delete(propsReaderUtil.getValue("sample_delete"), params);
		return sampleMap;
	}

	@Override
	public Map<String, Object> get(Long id) throws Exception {
		System.out.println("inside ipdate service impl..."+id);
		Object []params={id};
		return baseDao.get(propsReaderUtil.getValue("sample_get"), params);

	}

	@Override
	public List<Map<String, Object>> getlist() throws Exception {
		System.out.println("inside Update service impl...");
		return baseDao.getList(propsReaderUtil.getValue("sample_get_list"), null);
	}

	@Override
	public Map validateSave(Map sampleMap) throws Exception {
		Map<String, Object> errorMsg=new HashMap<String, Object>();
		if(sampleMap.get("email")==null|sampleMap.get("email").equals("")){
			errorMsg.put("email", "email is required");	
		}
		if(sampleMap.get("phone")==null|sampleMap.get("phone").equals("")){
			errorMsg.put("phone", "phone is required");	
		}
		System.out.println(errorMsg);
		return errorMsg;
	}

	@Override
	public Map validateUpdate(Map sampleMap) throws Exception {
		Map<String, Object> errorMsg=null;
		
		return errorMsg;
	}

	@Override
	public Map validateDelete(Map sampleMap) throws Exception {
		Map<String, Object> errorMsg=null;
		
		return errorMsg;
	}

	@Override
	public Map validateGet(Long id) throws Exception {
		Map<String, Object> errorMsg=null;
		
		return errorMsg;
	}

}
