package com.legalcraft.kidolaa.dao.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.legalcraft.kidolaa.dao.BaseDao;
import com.legalcraft.kidolaa.util.PropsReaderUtil;

@Repository("baseDao")
public class BaseDaoImpl implements BaseDao {

	public Logger log = LoggerFactory.getLogger(BaseDaoImpl.class);

	@Autowired
	public JdbcTemplate writeTemplate;

	@Autowired
	public JdbcTemplate readTemplate;

	@Autowired
	public PropsReaderUtil propsReaderUtil;

	@Override
	public Long save(String query, Object[] params) throws Exception {
		log.debug("query in dao..." + query);
		writeTemplate.update(query, params);
		System.out.println(new Long(writeTemplate.queryForInt("select @@identity")));
		return writeTemplate.queryForLong("select LAST_INSERT_ID()");
	}

	@Override
	public void update(String query, Object[] params) throws Exception {
		log.debug("query in dao..." + query);
		writeTemplate.update(query, params);
	}

	@Override
	public void delete(String query, Object[] params) throws Exception {
		log.debug("query in dao..." + query);
		writeTemplate.update(query, params);
	}

	@Override
	public Map<String, Object> get(String query, Object[] params) {
		log.debug("query in dao..." + query);
		Map<String, Object> map = null;
		try {
			map = readTemplate.queryForMap(query, params);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		return map;
	}

	@Override
	public List<Map<String, Object>> getList(String query, Object... params) throws Exception {
		log.debug("query in dao..." + query);
		return readTemplate.queryForList(query, params);
	}
}
