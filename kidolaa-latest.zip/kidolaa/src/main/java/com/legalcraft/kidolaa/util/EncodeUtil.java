package com.legalcraft.kidolaa.util;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

public class EncodeUtil {

	public static String encodePassword(String inpuString){
		String base64encodedString=null;
		try {
	         // Encode using basic encoder
	         base64encodedString = Base64.getEncoder().encodeToString(inpuString.getBytes("utf-8"));
	         System.out.println("Base64 Encoded String (Basic) :" + base64encodedString);		   
	      }catch(UnsupportedEncodingException e){
	         System.out.println("Error :" + e.getMessage());
	      }
		return base64encodedString;

	}
	
	public static String decodePassword(String inpuString){
		String decodedValue=null;
		try {
	         byte[] base64decodedBytes = Base64.getDecoder().decode(inpuString);
	         decodedValue=new String(base64decodedBytes, "utf-8");
	         System.out.println("decoded value:::"+decodedValue);
	      }catch(UnsupportedEncodingException e){
	         System.out.println("Error :" + e.getMessage());
	      }
		return decodedValue;
	}
	
	public static void main(String...args){
		EncodeUtil.encodePassword("akbar");
		EncodeUtil.decodePassword("YWtiYXI=");
	}

}
