package com.legalcraft.kidolaa.model;

/**
 * 
 * @author Akbar
 *
 */
public class KidolaaThreadLocal{

	 public static final ThreadLocal<UserContext> localUser=new ThreadLocal<UserContext>();
	 
	 public static void setUserContext(UserContext userContext){
		 localUser.set(userContext);
	 }
	 
	 public static UserContext getUserContext(){
		 return localUser.get();
	 }
	 
	 public void resetUserContext(){
		 localUser.remove();
	 }
}
