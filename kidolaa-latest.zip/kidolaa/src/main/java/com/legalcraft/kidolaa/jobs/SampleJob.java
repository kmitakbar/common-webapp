package com.legalcraft.kidolaa.jobs;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class SampleJob {

	//@Scheduled(cron="{*/5 * * * * ?}")
	public void doSomething() {
	    System.out.println("scheduled job....");
	}
}
