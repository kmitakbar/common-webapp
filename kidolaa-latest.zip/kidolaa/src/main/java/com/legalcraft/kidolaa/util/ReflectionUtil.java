package com.legalcraft.kidolaa.util;

import java.lang.reflect.Method;

public class ReflectionUtil {

	
	public void performOperation(String className,String operation,String data) {
		System.out.println("full qualified class name"+className+"op:"+operation+"::data::"+data);
		//no paramater
		Class noparams[] = {};
			
		//String parameter
		Class[] paramString = new Class[1];	
		paramString[0] = String.class;
				
		try{
		        //load the AppTest at runtime
			Class cls = Class.forName(className);
			Object obj = cls.newInstance();
			Method method=null;
			if(data!=null){
			method = cls.getDeclaredMethod(operation, noparams);
			method.invoke(obj, null);
			}else{
			//call the printItString method, pass a String param 
			method = cls.getDeclaredMethod(operation, paramString);
			System.out.println("invoking method:::::");
			method.invoke(obj, data);
			}
				
		}catch(Exception ex){
			ex.printStackTrace();
		}
	   }
	public Object getInstance(String className){
		Object obj=null;
		try{
			Class cls = Class.forName(className);
			obj = cls.newInstance();
			
		}catch(Exception e){
			System.out.println(e);
		}
		return obj;
	}
}
