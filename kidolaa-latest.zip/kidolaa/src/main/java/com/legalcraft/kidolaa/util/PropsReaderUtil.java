package com.legalcraft.kidolaa.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

/**
 * 
 *
 * This class is used to read the properties from the properties
 * file presented in classpath.we can read multiple properties values by
 * using single class
 */
@PropertySources({ @PropertySource("classpath:message.properties"),
		@PropertySource("classpath:kidolaa-queries.sql")})
@Service
public class PropsReaderUtil {

	@Autowired
	Environment environment;

	public String getValue(String key) {
		System.out.println("key::::"+environment.getProperty(key));
		return environment.getProperty(key);
	}
}
