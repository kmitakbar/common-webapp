package com.legalcraft.kidolaa.model;

public class WebResponse {
	private Object response;
	private String errorMsg;
	private String successMsg;
	
	public WebResponse() {
		// TODO Auto-generated constructor stub
	}
	public WebResponse(Object response,String errorMsg,String successMsg){
		this.response=response;
		this.errorMsg=errorMsg;
		this.successMsg=successMsg;
	}
	public Object getResponse() {
		return response;
	}
	public void setResponse(Object response) {
		this.response = response;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getSuccessMsg() {
		return successMsg;
	}
	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}
	@Override
	public String toString() {
		return "WebResponse [response=" + response + ", errorMsg=" + errorMsg + ", successMsg=" + successMsg + "]";
	}
	
	
}
