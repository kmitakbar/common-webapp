package com.legalcraft.kidolaa.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.legalcraft.kidolaa.model.KidolaaThreadLocal;
import com.legalcraft.kidolaa.model.User;
import com.legalcraft.kidolaa.model.UserContext;
import com.legalcraft.kidolaa.service.UserService;
import com.legalcraft.kidolaa.util.EncodeUtil;
import com.legalcraft.kidolaa.util.TokenUtil;

@Service("user")
@Transactional
public class UserServiceImpl extends BaseServiceImpl implements UserService {

	@Override
	public Map validateSave(Map sampleMap) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map validateUpdate(Map user) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map validateDelete(Map user) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map validateGet(Long id) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> save(Map<String, Object> user) throws Exception {
		Map<String, Object> errorMap=null;
		if(true){
			Object params[]={
					user.get("firstname"),
					user.get("lastname"),
					user.get("email"),
					user.get("loginname"),
					EncodeUtil.encodePassword((String) user.get("password"))
					};
			
			Long userId=baseDao.save(propsReaderUtil.getValue("create_user"), params);
			user.put("userId", userId);
			return user;
		}else{
		return errorMap;
		}
	}

	@Override
	public Map<String, Object> update(Map<String, Object> user) throws Exception {
		System.out.println(KidolaaThreadLocal.localUser.get());
		return null;
	}

	@Override
	public Map<String, Object> delete(Map<String, Object> sampleMap) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> get(Long id) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, Object>> getlist() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserContext login(Map<String, Object> userMap) throws Exception {
		UserContext userContext=null;
		User user=null;
		String authToken=null;
		Map<String, Object> currentuser=baseDao.get(propsReaderUtil.getValue("get_user_uname_pwd"), new Object[]{userMap.get("loginname"),EncodeUtil.encodePassword((String) userMap.get("password"))});
		if(currentuser!=null){
			userContext=new UserContext();
			user=new User();
			user.setUserId(new Long(currentuser.get("userId").toString()));
			user.setFirstName((String) currentuser.get("firstname"));
			user.setLastName((String) currentuser.get("lastname"));
			user.setEmailId((String) currentuser.get("email"));
			user.setLoginName((String) currentuser.get("loginname"));
			userContext.setAuthToken(TokenUtil.generateGUID());
			userContext.setUser(user);
		}
		
		return userContext;
	}

}
