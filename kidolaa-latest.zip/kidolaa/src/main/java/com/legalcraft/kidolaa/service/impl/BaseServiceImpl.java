package com.legalcraft.kidolaa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.legalcraft.kidolaa.dao.BaseDao;
import com.legalcraft.kidolaa.service.BaseService;
import com.legalcraft.kidolaa.util.PropsReaderUtil;

abstract public class BaseServiceImpl<T> implements BaseService<T> {
	@Autowired
	public PropsReaderUtil propsReaderUtil;
	
	@Autowired
	public BaseDao baseDao;
}
