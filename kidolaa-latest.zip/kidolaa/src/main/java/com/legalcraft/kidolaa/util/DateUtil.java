/**
 * Copyright (c) 2013 Exaact. All rights reserved.
 */
package com.legalcraft.kidolaa.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Util class to have all the common date related methods
 */
public class DateUtil {

	public static final String MM_dd_yyyy = "MM-dd-yyyy";

	private static final String DATE_FORMAT = "yyyy-MM-dd";

	private static final String DATE_FORMAT_WITHOUT_TIME = "yyyy-MM-dd";

	public static Date getCurrentDate() {
		return new Date();
	}

	public static Date getDate(String dateStr, String pattern) {
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		Date date = null;
		try {
			date = format.parse(dateStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date;
	}

	public static Date getDateFromString(String dateString) {
		Date date = null;
		try {
			DateFormat format = new SimpleDateFormat(MM_dd_yyyy);
			date = format.parse(dateString);
		} catch (ParseException ex) {
			ex.printStackTrace();
		}
		return date;
	}
	
	public static Date getDateWithoutTimeFromString(String dateString) {
		Date date = null;
		try {
			DateFormat format = new SimpleDateFormat(DATE_FORMAT_WITHOUT_TIME);
			date = format.parse(dateString);
		} catch (ParseException ex) {
			ex.printStackTrace();
		}
		return date;
	}

	public static void main(String[] args) {
		System.out.println(getDateFromString("04-25-2013"));
	}
}
