package com.legalcraft.kidolaa.notification;

import java.io.File;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("sendNotification")
public class SendNotification {

	@Autowired
	public SendEmail sendEmail;

	public void send(String to, String from, String subject, String templatePath, Map map) {
		sendEmail.send(to, from, subject, templatePath, map);
	}
	
	public void send(String to, String from, String subject, String templatePath, File attachment, Map map) {
		sendEmail.send(to, from, subject, templatePath,attachment,  map);
	}
		
}
