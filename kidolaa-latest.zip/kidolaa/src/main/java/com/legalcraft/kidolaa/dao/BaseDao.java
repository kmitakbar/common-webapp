package com.legalcraft.kidolaa.dao;

import java.util.List;
import java.util.Map;

public interface BaseDao {
public Long save(String query,Object[]params)throws Exception;
public void update(String query,Object[]params)throws Exception;
public void delete(String query,Object[]params)throws Exception;
public Map<String, Object> get(String query,Object[]params)throws Exception;
public List<Map<String, Object>> getList(String query,Object[]params)throws Exception;
}
