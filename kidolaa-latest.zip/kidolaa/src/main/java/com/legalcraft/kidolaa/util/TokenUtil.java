/**
 * Copyright (c) 2013 Exaact. All rights reserved.
 */
package com.legalcraft.kidolaa.util;

import java.util.Calendar;
import java.util.Random;

/**
 * 
 * @author Administrator
 *
 */
public class TokenUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Token 1 :: ["+generateGUID()+"]");
		System.out.println("Token 2 :: ["+generateGUID()+"]");
		System.out.println("Token 3 :: ["+generateGUID()+"]");
		System.out.println("Token 4 :: ["+generateGUID()+"]");

	}
	
	/**
	 * 
	 * @return
	 */
	public static String generateGUID() {
		Calendar cal = Calendar.getInstance();
		int milliSeconds = cal.get(Calendar.MILLISECOND);
		int seconds = cal.get(Calendar.SECOND);
		String milliSecondsHex = Integer.toHexString(milliSeconds* 1000000);
		String secondsHex = Integer.toHexString(seconds);
		ensureLength(milliSecondsHex, 5);
		ensureLength(secondsHex, 6);
		String ret = milliSecondsHex + "";
		ret += createGUIDSection(3);
		ret += '-';
		ret += createGUIDSection(4);
		ret += '-';
		ret += createGUIDSection(4);
		ret += '-';
		ret += createGUIDSection(4);
		ret += '-';
		ret += secondsHex;
		ret += createGUIDSection(6);
		return ret;
	}
	
	/**
	 * 
	 * @param original
	 * @param length
	 */
	private static void ensureLength(String original, int length) {
		int diff = original.length() - length;
		if (diff > 0) {
			// String is too long; trim it down to the proper side
			original = original.substring(0, length);
		} else if (diff < 0 ) {
			// String is too short; pad it with trailing zeroes
			for (int i = 0; i < diff; i ++) {
				original += "0";
			}
		}
		return;
		
	}
	
	/**
	 * 
	 * @param characters
	 * @return
	 */
	private static String createGUIDSection (int characters) {
		String ret = "";
		Random random = new Random();
		for (int i=0; i < characters; i++) {
			ret += Integer.toHexString(random.nextInt(15));
        }
		return ret;
	}
}
