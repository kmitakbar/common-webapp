package com.legalcraft.kidolaa.model;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

/**
 * 
 * 
 * @author Akbar
 *
 */
@Component
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class UserContext {
	
	private User user;
	private String authToken;
	
	
	public UserContext(){
		
	}
	
	public UserContext(User user, String token){
		this.user = user;
		this.authToken = token;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	@Override
	public String toString() {
		return "UserContext [user=" + user + ", authToken=" + authToken + "]";
	}
	
	

}
