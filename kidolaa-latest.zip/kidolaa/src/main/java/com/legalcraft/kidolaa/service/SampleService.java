package com.legalcraft.kidolaa.service;

import java.util.List;
import java.util.Map;


public interface SampleService extends BaseService{

	public Map<String, Object> save(Map<String, Object> sampleMap) throws Exception;
	
	public Map<String, Object> update(Map<String, Object> sampleMap) throws Exception;
	
	public Map<String, Object> delete(Map<String, Object> sampleMap) throws Exception;
	
	public Map<String, Object> get(Long id) throws Exception;
	
	public List<Map<String, Object>> getlist() throws Exception;
}
