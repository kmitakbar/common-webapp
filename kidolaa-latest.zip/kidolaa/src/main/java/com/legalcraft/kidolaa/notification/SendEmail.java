package com.legalcraft.kidolaa.notification;

import java.io.File;
import java.util.Map;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.MailPreparationException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;


@Service("sendEmail")
public class SendEmail {

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private VelocityEngine velocityEngine;

	public boolean send(SimpleMailMessage mailMessage) {
		try {
			mailSender.send(mailMessage);
		} catch (Exception e) {
			System.out.println("Failed sending mail " + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean send(MimeMessage mimeMessage) throws Exception {

		try {
			Multipart multipart = new MimeMultipart();
			BodyPart bodyPart = new MimeBodyPart();
			multipart.addBodyPart(bodyPart);
			bodyPart.setContent(mimeMessage.getContent(), "text/html");
			mimeMessage.setContent(multipart);
			mailSender.send(mimeMessage);
		} catch (Exception e) {
			System.out.println("Failed sending mail " + e.getMessage());
			throw e;
		}
		return true;
	}

	public boolean send(String to, String from, String subject, String templatePath, Map map) {
		// create a mime message using the mail sender implementation
		MimeMessage mimeMessage = mailSender.createMimeMessage();

		// create the message using the specified template
		MimeMessageHelper helper;
		try {
			// mimeMessage.addHeaderLine("email.democrasoft.com");
			helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setFrom(from);

			String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, templatePath, map);
			// String text = "Test from app -- Murali";
			helper.setText(text, true);
			send(mimeMessage);
			System.out.println("SUCCESS: Sendig mail to " + to + " from " + from + " subject " + subject);
		} catch (MessagingException e) {
			throw new MailPreparationException("unable to create the mime message helper", e);
		} catch (Exception e) {
			System.out.println("FAILED: Sendig mail to " + to + " from " + from + " subject " + subject);
		}
		return false;
	}

	public boolean send(String to, String from, String subject, String msgText) {
		// create a mime message using the mail sender implementation
		MimeMessage mimeMessage = mailSender.createMimeMessage();

		// create the message using the specified template
		MimeMessageHelper helper;
		try {
			helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setFrom(from);
			helper.setText(msgText, true);
			send(mimeMessage);
		} catch (MessagingException e) {
			throw new MailPreparationException("unable to create the mime message helper", e);
		} catch (Exception e) {
			System.out.println("FAILED: Sendig mail to " + to + " from " + from + " subject " + subject);
		}
		return false;
	}
	
	public boolean send(String to, String from, String subject, String templatePath, File attachment, Map map) {
		// create a mime message using the mail sender implementation
		MimeMessage mimeMessage = mailSender.createMimeMessage();

		// create the message using the specified template
		MimeMessageHelper helper;
		try {
			// mimeMessage.addHeaderLine("email.democrasoft.com");
			helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setFrom(from);

			String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, templatePath, map);
			// String text = "Test from app -- Murali";
			helper.setText(text, true);
			if(attachment!=null && attachment.exists()) {
				FileSystemResource file = new FileSystemResource(attachment);
				helper.addAttachment(file.getFilename(), file);
			}
			send(mimeMessage);
			System.out.println("SUCCESS: Sendig mail to " + to + " from " + from + " subject " + subject);
		} catch (MessagingException e) {
			throw new MailPreparationException("unable to create the mime message helper", e);
		} catch (Exception e) {
			System.out.println("FAILED: Sendig mail to " + to + " from " + from + " subject " + subject);
		}
		return false;
	}

	public boolean send(String to, String from, String subject, String msgText, File attachment) {
		// create a mime message using the mail sender implementation
		MimeMessage mimeMessage = mailSender.createMimeMessage();

		// create the message using the specified template
		MimeMessageHelper helper;
		try {
			helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setFrom(from);
			helper.setText(msgText, true);
			FileSystemResource file = new FileSystemResource(attachment);
			helper.addAttachment(file.getFilename(), file);
			send(mimeMessage);
		} catch (MessagingException e) {
			throw new MailPreparationException("unable to create the mime message helper", e);
		} catch (Exception e) {
			System.out.println("FAILED: Sendig mail to " + to + " from " + from + " subject " + subject);
		}
		return false;
	}
}
