package com.legalcraft.kidolaa.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.legalcraft.kidolaa.service.impl.BaseServiceImpl;

public interface BaseService<T> {

	public Logger log=LoggerFactory.getLogger(BaseServiceImpl.class);
	/*public T create(T obj);
	public T update(T obj);
	public T delete(T obj);
	public T get(T obj);
	public List<T> getList();
	public T validate4Create(T obj);
	public T validate4Update(T obj);
	public T validate4Delete(T obj);*/
	
	public Map<String, Object> validateSave(Map<String, Object> sampleMap) throws Exception;
	
	public Map<String, Object> validateUpdate(Map<String, Object> sampleMap) throws Exception;
	
	public Map<String, Object> validateDelete(Map<String, Object> sampleMap) throws Exception;
	
	public Map<String, Object> validateGet(Long id) throws Exception;
	
}
