package com.legalcraft.kidolaa.service;

import java.util.List;
import java.util.Map;

import com.legalcraft.kidolaa.model.UserContext;

public interface UserService extends BaseService {

	public Map<String, Object> save(Map<String, Object> user) throws Exception;

	public Map<String, Object> update(Map<String, Object> user) throws Exception;

	public Map<String, Object> delete(Map<String, Object> user) throws Exception;

	public Map<String, Object> get(Long id) throws Exception;

	public List<Map<String, Object>> getlist() throws Exception;
	
	public UserContext login(Map<String, Object> user)throws Exception;
}
