package com.legalcraft.kidolaa.model;

/**
 * 
 * @author Akbar
 * 
 */
public class User {

	private long userId;
	private String firstName;
	private String lastName;
	private String emailId;
	private String loginName;
	private String password;
	private String profilePicLocation;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getProfilePicLocation() {
		return profilePicLocation;
	}
	public void setProfilePicLocation(String profilePicLocation) {
		this.profilePicLocation = profilePicLocation;
	}
	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", emailId=" + emailId
				+ ", loginName=" + loginName + ", password=" + password + ", profilePicLocation=" + profilePicLocation
				+ "]";
	}
	
	
	
	
	
}
